package stocktrack;

import java.time.LocalDate;

public class Product {
    private final String sku;
    private String name;
    private int qty;
    private double price;
    private LocalDate expiry;
    private int reorderLevel;
    private double dailyDemand; // average units sold per day

    public Product(String sku, String name, int qty, double price,
                   LocalDate expiry, int reorderLevel, double dailyDemand) {
        this.sku = sku; this.name = name; this.qty = qty; this.price = price;
        this.expiry = expiry; this.reorderLevel = reorderLevel; this.dailyDemand = dailyDemand;
    }

    public String getSku() { return sku; }
    public String getName() { return name; }
    public int getQty() { return qty; }
    public double getPrice() { return price; }
    public LocalDate getExpiry() { return expiry; }
    public int getReorderLevel() { return reorderLevel; }
    public double getDailyDemand() { return dailyDemand; }
    public double getValue() { return price * qty; }

    public void setName(String name) { this.name = name; }
    public void setQty(int qty) { this.qty = qty; }
    public void setPrice(double price) { this.price = price; }
    public void setExpiry(LocalDate expiry) { this.expiry = expiry; }

    @Override
    public String toString() {
        return String.format("%-8s %-18s qty=%-4d P%-8.2f exp=%s", sku, name, qty, price, expiry);
    }
}
