package stocktrack;

import java.time.LocalDateTime;

/** One stock movement. change > 0 is stock-in, change < 0 is stock-out. */
public record Transaction(String sku, int change, LocalDateTime time) {
    public Transaction(String sku, int change) { this(sku, change, LocalDateTime.now()); }

    @Override
    public String toString() {
        return time.withNano(0) + "  " + sku + "  " + (change > 0 ? "IN +" : "OUT ") + change;
    }
}
