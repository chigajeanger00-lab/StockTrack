package stocktrack;

import java.time.LocalDate;
import java.util.*;

/** Core logic. Each section notes which data structure / algorithm it demonstrates. */
public class InventoryManager {
    // HASH TABLE: O(1) average lookup by SKU
    private final Map<String, Product> products = new HashMap<>();
    // LINKED LIST: transaction history, O(1) add at end
    private final LinkedList<Transaction> log = new LinkedList<>();
    // STACK: undo, last transaction is reversed first
    private final Deque<Transaction> undoStack = new ArrayDeque<>();

    // ---------- Products ----------
    public boolean addProduct(Product p) { return products.putIfAbsent(p.getSku(), p) == null; }
    public Product find(String sku) { return products.get(sku); }
    public boolean remove(String sku) { return products.remove(sku) != null; }
    public List<Product> all() { return new ArrayList<>(products.values()); }
    public List<Transaction> history() { return log; }

    // ---------- Stock movements ----------
    public boolean stockIn(String sku, int qty) {
        Product p = products.get(sku);
        if (p == null || qty <= 0) return false;
        p.setQty(p.getQty() + qty);
        record(new Transaction(sku, qty));
        return true;
    }

    public boolean stockOut(String sku, int qty) {
        Product p = products.get(sku);
        if (p == null || qty <= 0 || p.getQty() < qty) return false;
        p.setQty(p.getQty() - qty);
        record(new Transaction(sku, -qty));
        return true;
    }

    private void record(Transaction t) { log.addLast(t); undoStack.push(t); }

    public boolean undo() {
        if (undoStack.isEmpty()) return false;
        Transaction t = undoStack.pop();
        log.removeLast();
        Product p = products.get(t.sku());
        if (p != null) p.setQty(p.getQty() - t.change());
        return true;
    }

    // ---------- Alerts ----------
    // MIN-HEAP (PriorityQueue): most urgent item comes out first, O(log n)
    public List<Product> lowStockAlerts() {
        PriorityQueue<Product> heap = new PriorityQueue<>(
                Comparator.comparingInt(p -> p.getQty() - p.getReorderLevel()));
        for (Product p : products.values()) if (p.getQty() <= p.getReorderLevel()) heap.add(p);
        List<Product> out = new ArrayList<>();
        while (!heap.isEmpty()) out.add(heap.poll());
        return out;
    }

    public List<Product> expiringSoon(int days) {
        PriorityQueue<Product> heap = new PriorityQueue<>(Comparator.comparing(Product::getExpiry));
        LocalDate limit = LocalDate.now().plusDays(days);
        for (Product p : products.values())
            if (p.getExpiry() != null && !p.getExpiry().isAfter(limit)) heap.add(p);
        List<Product> out = new ArrayList<>();
        while (!heap.isEmpty()) out.add(heap.poll());
        return out;
    }

    // QUEUE (FEFO): earliest expiry is sold first
    public Queue<Product> fefoQueue() {
        List<Product> list = mergeSort(all(), Comparator.comparing(Product::getExpiry));
        return new ArrayDeque<>(list);
    }

    // ---------- Sorting and searching ----------
    // MERGE SORT: stable, O(n log n) time, O(n) space
    public static <T> List<T> mergeSort(List<T> list, Comparator<T> cmp) {
        if (list.size() <= 1) return new ArrayList<>(list);
        int mid = list.size() / 2;
        List<T> left = mergeSort(list.subList(0, mid), cmp);
        List<T> right = mergeSort(list.subList(mid, list.size()), cmp);
        List<T> merged = new ArrayList<>(list.size());
        int i = 0, j = 0;
        while (i < left.size() && j < right.size())
            merged.add(cmp.compare(left.get(i), right.get(j)) <= 0 ? left.get(i++) : right.get(j++));
        while (i < left.size()) merged.add(left.get(i++));
        while (j < right.size()) merged.add(right.get(j++));
        return merged;
    }

    // BINARY SEARCH: list must already be sorted by name, O(log n)
    public static Product binarySearchByName(List<Product> sortedByName, String name) {
        int lo = 0, hi = sortedByName.size() - 1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            int c = sortedByName.get(mid).getName().compareToIgnoreCase(name);
            if (c == 0) return sortedByName.get(mid);
            if (c < 0) lo = mid + 1; else hi = mid - 1;
        }
        return null;
    }

    // ---------- Reorder formulas ----------
    /** Reorder point = demand during lead time + safety stock. */
    public static int reorderPoint(double dailyDemand, int leadTimeDays, int safetyStock) {
        return (int) Math.ceil(dailyDemand * leadTimeDays) + safetyStock;
    }

    /** Economic Order Quantity = sqrt(2 * D * S / H). */
    public static int eoq(double annualDemand, double orderCost, double holdingCostPerUnit) {
        return (int) Math.ceil(Math.sqrt(2 * annualDemand * orderCost / holdingCostPerUnit));
    }

    // ---------- ABC analysis ----------
    /** A = top 80% of stock value, B = next 15%, C = the rest. */
    public Map<String, Character> abcAnalysis() {
        List<Product> sorted = mergeSort(all(), Comparator.comparingDouble(Product::getValue).reversed());
        double total = 0;
        for (Product p : sorted) total += p.getValue();
        Map<String, Character> result = new LinkedHashMap<>();
        double running = 0;
        for (Product p : sorted) {
            running += p.getValue();
            double share = total == 0 ? 1 : running / total;
            result.put(p.getSku(), share <= 0.80 ? 'A' : share <= 0.95 ? 'B' : 'C');
        }
        return result;
    }
}
