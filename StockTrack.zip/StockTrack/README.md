# StockTrack (Java, NetBeans)

Starter project for the Inventory & Supply Chain proposal.

## Open in NetBeans
File > Open Project > select the `StockTrack` folder (Maven project, needs JDK 17+).
Run: right-click project > Run. Test: right-click project > Test.

## What is already done
- Hash Table (HashMap): product lookup by SKU
- Linked List: transaction history
- Stack: undo
- Min-Heap (PriorityQueue): low-stock and expiry alerts
- Queue: FEFO order
- Merge Sort, Binary Search, Reorder Point, EOQ, ABC Analysis

## To do (team)
- Supplier comparison (Jaimer)
- Save/load data (Jaimer)
- Swing UI (Riezen)
- More tests + Big-O notes in the planner
