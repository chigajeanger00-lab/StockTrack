# Manual test cases

Use the demo data (delete `stocktrack.db` first so every tester starts the same).
Write Pass or Fail in the Result column and the version you tested. If it fails, write what happened in Notes.

**Version tested:** ______  **Tester:** ______  **Date:** ______

| ID | Feature | Steps | Expected result | Result | Notes |
|---|---|---|---|---|---|
| TC-01 | Login (owner) | Enter `owner` / `owner123`, click Log in | Dashboard opens, header shows "Hi, owner (Owner)" | | |
| TC-02 | Login (wrong password) | Enter `owner` / `wrong` | Message "Wrong username or password. Try again." and the dashboard does not open | | |
| TC-03 | Login (staff) | Log in as `staff` / `staff123` | Dashboard has no Add product, Edit, Delete, or Discard expired buttons | | |
| TC-04 | Search | Type `milk` in Search | Only Fresh Milk is listed | | |
| TC-05 | Stock out | Select Bottled Water, Stock out, enter 5 | Quantity becomes 10 and the status line says "Removed 5 from Bottled Water. Now 10 in stock." | | |
| TC-06 | Stock out too many | Select Bottled Water, Stock out, enter 99 | Message "Enter a number from 1 to ..." and stock does not change | | |
| TC-07 | Stock out, not a number | Select any product, Stock out, enter `abc` | Message asking for a whole number | | |
| TC-08 | Stock in | Select Rice 1kg, Stock in, 10 units, expiry 2027-06-30 | Quantity increases by 10 and History shows "Stock in" | | |
| TC-09 | Undo | After TC-05, click Undo | Bottled Water goes back to 15 | | |
| TC-10 | Add product | Owner: Add product with a new SKU, name, qty, price, expiry, level | Product appears in the list | | |
| TC-11 | Duplicate SKU | Add a product using SKU-001 | Message "That SKU already exists. Use a different one." | | |
| TC-12 | Edit product | Owner: select a product, Edit, change the price | New price shows in the table | | |
| TC-13 | Delete product | Owner: select a product, Delete, confirm | Product is removed | | |
| TC-14 | Discard expired (none) | Click Discard expired with no expired stock | Message "No expired stock to discard." | | |
| TC-15 | Discard expired | Stock in 5 units with a past expiry date, then Discard expired | The 5 units are removed, History shows "Discarded (expired)", and Reports do not count them as sales | | |
| TC-16 | Low stock alert | Look at the Alerts panel on a fresh database | Shows Bottled Water as low stock and Fresh Milk as expiring | | |
| TC-17 | Reorder suggestion | Open Reorder | Bottled Water is listed with a supplier and a suggested quantity | | |
| TC-18 | Create order | In Reorder, select Bottled Water, Create purchase order | Order #1 appears in Orders as PENDING | | |
| TC-19 | Approve (owner) | Owner: Orders, select the order, Approve | Status becomes APPROVED | | |
| TC-20 | Approve (staff) | Log in as staff, open Orders | There is no Approve or Cancel order button | | |
| TC-21 | Receive order | Select an APPROVED order, Mark received, enter an expiry date | Status becomes RECEIVED and the stock increases by the ordered quantity | | |
| TC-22 | Receive before approval | Select a PENDING order, Mark received | Message that only approved orders can be received | | |
| TC-23 | Cancel order | Owner: select a PENDING order, Cancel order, Yes | Status becomes CANCELLED | | |
| TC-24 | Price comparison | Open Suppliers | Fresh Milk shows Farm and Dairy Co. as the best supplier | | |
| TC-25 | Add supplier and price | Owner: Add supplier, then Set price for a product | New supplier shows in the list and in the comparison | | |
| TC-26 | Best sellers | Open Reports on a fresh database | Instant Noodles is rank 1 with 30 units sold | | |
| TC-27 | Find by name | In Reports, type `rice 1kg`, click Find | Shows SKU-005 with its stock and price | | |
| TC-28 | History | Do a stock out, then open History | The newest movement is at the top | | |
| TC-29 | Data is saved | Make a change, close the app, open it again | The change is still there | | |
| TC-30 | Reset | Close the app, delete `stocktrack.db`, open the app | Demo data is back | | |
| TC-31 | Log out | Click Log out | Login screen appears and data is kept | | |
| TC-32 | MariaDB not running | Create `stocktrack.properties` for MariaDB, stop MariaDB, run the app | Error "Cannot connect to the database" and the app closes | | |
| TC-33 | MariaDB saves data | With MariaDB running and configured, stock out 5 Bottled Water, close and reopen the app, then check the `transactions` table | Stock is still reduced and the table has the new row | | |
