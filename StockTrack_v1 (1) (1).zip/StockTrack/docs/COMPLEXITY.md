# Time and space complexity (n = number of products)

| Data structure / algorithm | Used for | Operation | Time | Space |
|---|---|---|---|---|
| Hash Table (`HashMap`) | Find product by SKU | search / insert / delete | O(1) average | O(n) |
| Linked List (`LinkedList`) | Transaction history | add at end / traverse | O(1) / O(n) | O(t), t = transactions |
| Stack (`ArrayDeque`) | Undo | push / pop | O(1) | O(t) |
| Min-Heap (`PriorityQueue`) | Low-stock and expiry alerts | insert / remove most urgent | O(log n) each, O(n log n) to list all | O(n) |
| Queue (FEFO) | Sell earliest-expiring first | enqueue / dequeue | O(1) after one O(n log n) sort | O(n) |
| Merge Sort | Sort products, suggestions, reports | sort | O(n log n) always | O(n) |
| Binary Search | Find product by exact name | search | O(log n) | O(1) |
| Reorder Point formula | When to reorder | compute | O(1) per product | O(1) |
| EOQ formula | How much to order | compute | O(1) per product | O(1) |
| ABC Analysis | Rank products by stock value | classify | O(n log n) (sort) + O(n) | O(n) |
| Best supplier search | Cheapest supplier per product | linear scan of suppliers | O(s), s = suppliers | O(1) |
| Batches (FEFO per product) | Sell oldest stock first | stock out | O(b), b = batches of that product | O(b) |

Why these were chosen is explained in the proposal (Section 3).
