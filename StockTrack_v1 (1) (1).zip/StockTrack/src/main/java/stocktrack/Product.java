package stocktrack;

import java.time.LocalDate;
import java.util.*;

public class Product {
    private static final Comparator<Batch> BY_EXPIRY =
            Comparator.comparing((Batch b) -> b.expiry, Comparator.nullsLast(Comparator.naturalOrder()));

    private final String sku;
    private String name;
    private double price;
    private int reorderLevel;
    private double dailyDemand; // average units sold per day
    private final List<Batch> batches = new ArrayList<>(); // always sorted by expiry (FEFO order)

    public Product(String sku, String name, int qty, double price,
                   LocalDate expiry, int reorderLevel, double dailyDemand) {
        this.sku = sku; this.name = name; this.price = price;
        this.reorderLevel = reorderLevel; this.dailyDemand = dailyDemand;
        if (qty > 0) batches.add(new Batch(expiry, qty));
    }

    public String getSku() { return sku; }
    public String getName() { return name; }
    public double getPrice() { return price; }
    public int getReorderLevel() { return reorderLevel; }
    public double getDailyDemand() { return dailyDemand; }
    public void setName(String name) { this.name = name; }
    public void setPrice(double price) { this.price = price; }
    public void setReorderLevel(int reorderLevel) { this.reorderLevel = reorderLevel; }
    public void setDailyDemand(double dailyDemand) { this.dailyDemand = dailyDemand; }
    public List<Batch> getBatches() { return Collections.unmodifiableList(batches); }

    public int getQty() { int s = 0; for (Batch b : batches) s += b.qty; return s; }
    public double getValue() { return price * getQty(); }
    /** Earliest expiry among the batches in stock, or null. */
    public LocalDate getExpiry() { return batches.isEmpty() ? null : batches.get(0).expiry; }

    public void addBatch(LocalDate expiry, int qty) {
        for (Batch b : batches) if (Objects.equals(b.expiry, expiry)) { b.qty += qty; return; }
        batches.add(new Batch(expiry, qty));
        batches.sort(BY_EXPIRY);
    }

    /** FEFO: takes units from the earliest-expiring batch first. Returns what was taken. */
    public List<Batch> consumeFefo(int qty) {
        List<Batch> used = new ArrayList<>();
        Iterator<Batch> it = batches.iterator();
        while (qty > 0 && it.hasNext()) {
            Batch b = it.next();
            int take = Math.min(qty, b.qty);
            used.add(new Batch(b.expiry, take));
            b.qty -= take; qty -= take;
            if (b.qty == 0) it.remove();
        }
        return used;
    }

    /** Removes units from one batch first (used by undo), then from the earliest batches if it ran short. */
    public void removeFromBatch(LocalDate expiry, int qty) {
        Iterator<Batch> it = batches.iterator();
        while (it.hasNext() && qty > 0) {
            Batch b = it.next();
            if (!Objects.equals(b.expiry, expiry)) continue;
            int take = Math.min(qty, b.qty);
            b.qty -= take; qty -= take;
            if (b.qty == 0) it.remove();
        }
        if (qty > 0) consumeFefo(qty);
    }

    /** Removes every batch that expired before today. Returns what was removed. */
    public List<Batch> removeExpired(LocalDate today) {
        List<Batch> removed = new ArrayList<>();
        Iterator<Batch> it = batches.iterator();
        while (it.hasNext()) {
            Batch b = it.next();
            if (b.expiry != null && b.expiry.isBefore(today)) { removed.add(new Batch(b.expiry, b.qty)); it.remove(); }
        }
        return removed;
    }

    public void restore(List<Batch> pieces) { for (Batch b : pieces) addBatch(b.expiry, b.qty); }

    @Override
    public String toString() {
        return String.format("%-8s %-18s qty=%-4d P%-8.2f exp=%s", sku, name, getQty(), price, getExpiry());
    }
}
