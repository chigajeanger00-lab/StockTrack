package stocktrack;

import java.time.LocalDate;

/** Demo data used the first time the app runs (before any saved file exists). */
public class SampleData {
    public static void load(InventoryManager inv) {
        LocalDate t = LocalDate.now();
        inv.addProduct(new Product("SKU-001", "Instant Noodles", 150, 12.0, t.plusDays(90), 30, 8));
        inv.addProduct(new Product("SKU-002", "Bottled Water", 35, 20.0, t.plusDays(300), 25, 10));
        inv.addProduct(new Product("SKU-003", "Fresh Milk", 50, 65.0, t.plusDays(7), 20, 6));
        inv.addProduct(new Product("SKU-004", "Canned Sardines", 60, 28.0, t.plusDays(400), 20, 4));
        inv.addProduct(new Product("SKU-005", "Rice 1kg", 225, 55.0, t.plusDays(200), 50, 12));
        inv.stockOut("SKU-001", 30); inv.stockOut("SKU-002", 20); inv.stockOut("SKU-003", 10); inv.stockOut("SKU-005", 25);
        inv.clearUndo();

        inv.addSupplier("Metro Wholesale", 2);
        inv.addSupplier("Prime Distributors", 4);
        inv.addSupplier("Farm and Dairy Co.", 1);
        String[] skus = {"SKU-001", "SKU-002", "SKU-003", "SKU-004", "SKU-005"};
        double[] metro = {10.5, 17, 60, 25, 50}, prime = {10, 16, 62, 24, 52};
        for (int i = 0; i < skus.length; i++) {
            inv.setPrice("Metro Wholesale", skus[i], metro[i]);
            inv.setPrice("Prime Distributors", skus[i], prime[i]);
        }
        inv.setPrice("Farm and Dairy Co.", "SKU-003", 58);
        inv.setPrice("Farm and Dairy Co.", "SKU-005", 51);
    }
}
