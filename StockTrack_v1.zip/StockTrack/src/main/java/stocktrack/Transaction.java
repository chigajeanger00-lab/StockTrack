package stocktrack;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/** One stock movement. change > 0 is stock-in, change < 0 is stock-out. discard = true means expired stock thrown away (not a sale). */
public record Transaction(String sku, int change, LocalDateTime time, LocalDate expiry, List<Batch> pieces, boolean discard) {
    public Transaction(String sku, int change) { this(sku, change, LocalDateTime.now(), null, List.of(), false); }
    public Transaction(String sku, int change, LocalDate expiry, List<Batch> pieces) {
        this(sku, change, LocalDateTime.now(), expiry, pieces, false);
    }

    @Override
    public String toString() {
        return time.withNano(0) + "  " + sku + "  " + (discard ? "DISCARD " : change > 0 ? "IN +" : "OUT ") + change;
    }
}
