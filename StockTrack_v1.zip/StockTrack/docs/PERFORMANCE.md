# Performance test (scalability)

Run `Benchmark.java` (right-click > Run File in NetBeans) on your own computer and paste your numbers in the table.
The sample numbers below were measured on a cloud test machine (Java 17), so yours will be different.

| Products (n) | 100,000 hash lookups (ms) | Merge sort (ms) | 10,000 binary searches (ms) | Low-stock heap (ms) | ABC analysis (ms) |
|---|---|---|---|---|---|
| 1,000 | 8.3 | 1.1 | 7.4 | 2.9 | 4.9 |
| 10,000 | 28.6 | 42.0 | 16.6 | 15.2 | 49.2 |
| 100,000 | 111.8 | 323.3 | 21.1 | 127.3 | 802.6 |

## How to explain the results
- **Hash lookup and binary search** barely grow when n grows 100 times. This matches O(1) average and O(log n).
- **Merge sort, heap alerts, and ABC analysis** grow a little faster than n, which matches O(n log n).
- Even with 100,000 products, every screen action finishes in under about one second, which is far more than a small store needs.
- Small variations (for example the hash lookup at 100,000) come from the computer's memory cache and from Java warming up, not from the algorithm.

## Your own results (fill in)
| Products (n) | Hash lookups | Merge sort | Binary search | Heap | ABC |
|---|---|---|---|---|---|
| 1,000 | | | | | |
| 10,000 | | | | | |
| 100,000 | | | | | |

Computer used: ____________  (CPU, RAM, Java version)
