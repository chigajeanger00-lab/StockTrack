package stocktrack;

/** Change this number (and the version in pom.xml) every time you give out a new build. */
public final class Version {
    public static final String NAME = "1.1.0";

    private Version() { }
}
