# Changelog

Format: version, date, what changed. Newest on top.
Rule: fixing a bug = 1.0.1, 1.0.2 ... / adding a feature = 1.1.0, 1.2.0 ... / big change = 2.0.0.

## 1.1.0 - 2026-10-21
- Added MariaDB support. Use it by copying `stocktrack.properties.example` to `stocktrack.properties` (see `docs/DATABASE_SETUP.md`). Without that file the app still uses SQLite.
- Login screen now shows which database is in use
- If the database cannot be reached, the app shows an error message and closes instead of failing quietly
- Empty database no longer reloads the demo data after you delete every product
- Renamed some table columns (`qty_change`, `moved_at`, `order_date`) because `change` is a reserved word in MariaDB. **If you used v1.0.0, delete the old `stocktrack.db` before running v1.1.0.**
- Added test cases TC-32 and TC-33 for MariaDB

## 1.0.0 - 2026-10-21 (first versioned release)
- Login with Owner and Staff roles
- Side menu: Inventory, Reorder, Suppliers, Orders, Reports, History
- Inventory: search, stock in with expiry, stock out (earliest expiry first), undo, add, edit, delete, discard expired stock
- Reorder suggestions (Reorder Point and EOQ) with cheapest supplier
- Suppliers and price comparison, purchase orders (pending, approved, received, cancelled)
- Reports: best sellers, slow movers, ABC summary, find by exact name (binary search)
- History of all stock movements
- SQLite database (`stocktrack.db`) saved automatically
- Docs: complexity table, performance test, interview template, test cases
- Benchmark.java for scalability tests

## Before 1.0.0 (internal builds, not versioned)
- Build 1: console starter with the core data structures and algorithms
- Build 2: first Swing dashboard
- Build 3: login and new design
- Build 4: reorder, suppliers, orders, reports, history, batches and expiry (FEFO)
- Build 5: side menu
- Build 6: edit product, discard expired, cancel order, benchmark
- Build 7: SQLite database instead of a text file
